---
title: Badge hd fill
categories:
  - Badges
tags:
  - display
  - resolution
  - "high definition"
---
