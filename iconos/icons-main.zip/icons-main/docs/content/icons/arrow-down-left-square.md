---
title: Arrow down left square
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
