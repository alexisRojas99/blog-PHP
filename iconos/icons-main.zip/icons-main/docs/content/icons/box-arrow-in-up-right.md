---
title: Box arrow in up right
categories:
  - Box arrows
tags:
  - arrow
---
